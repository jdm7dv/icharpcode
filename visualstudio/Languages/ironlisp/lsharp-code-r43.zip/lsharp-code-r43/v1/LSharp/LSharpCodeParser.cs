using System;
using System.CodeDom.Compiler;
using System.CodeDom;
using System.IO;
 
namespace LSharp
{
	/// <summary>
	/// Summary description for LSharpCodeParser.
	/// </summary>
	public class LSharpCodeParser : CodeParser
	{
		public override CodeCompileUnit Parse(TextReader t) 
		{
			throw new NotImplementedException();
		}
	}
}
